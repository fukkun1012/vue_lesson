import Vue from 'vue'
import App from './App.vue'
import router from './router.js'

Vue.config.productionTip = false

new Vue({
  router, // ここにvue-routerを設定
  render: h => h(App),
}).$mount('#app')
