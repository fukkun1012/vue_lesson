<template>
    <section>
        <h3>ユーザ詳細</h3>
        <p>ユーザID: {{ id }}</p>
    </section>
</template>

<script>
export default {
    props: ["id"],
    // watchではなくVue-Routerのナビゲーションガードを使用する方法がある
    // beforeRouteEnter(to, from, next) {
    //     console.log(from.path+'から'+to.path+'へ切り替えました');
    //     next();
    // }
}
</script>