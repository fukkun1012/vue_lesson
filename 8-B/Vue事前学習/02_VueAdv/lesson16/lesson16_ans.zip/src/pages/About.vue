<template>
    <section>
        <h3>このサイトについて</h3>
        <p>Lesson16の課題はルーティングについて学びます。<br>
        ルーティングは奥が深いのでしっかり理解して進めましょう。
        </p>
    </section>
</template>

<script>
export default {
    // watchではなくVue-Routerのナビゲーションガードを使用する方法がある
    // beforeRouteEnter(to, from, next) {
    //     console.log(from.path+'から'+to.path+'へ切り替えました');
    //     next();
    // }
}
</script>