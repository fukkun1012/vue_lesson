<template>
    <section>
        <h3>ホーム</h3>
        <img alt='LiNew Office' src='@/assets/office.jpg'>
    </section>
</template>

<script>
export default {
    // watchではなくVue-Routerのナビゲーションガードを使用する方法がある
    // beforeRouteEnter(to, from, next) {
    //     console.log(from.path+'から'+to.path+'へ切り替えました');
    //     next();
    // }
}
</script>