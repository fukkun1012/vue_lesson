<template>
  <section>
    <slot name='title'>ヘッダータイトル</slot>
    <slot name='subtitle'>サブタイトル</slot>
    <slot></slot>
  </section>
</template>

<!-- scopedを指定することでコンポーネント内のみstyleを反映できます -->
<style scoped>
h1 {
  font-size: 24px;
}
img {
  width: 3%;
  vertical-align: text-top;
}
</style>
