<template>
  <div id="app">
    <Header>
      <!-- 特定のv-slotに渡す場合はv-slot:xxxで指定する（v-slotは#で省略可） -->
      <template #title>
        <h1>{{ title }} <img alt="Vue logo" src="./assets/logo.png"></h1>
      </template>
      <template #subtitle>
        <h2>{{ subtitle }}</h2>
      </template>
      <hr/>
    </Header>  
    <img alt='LiNew Office' src='./assets/office.jpg'>
  </div>
</template>

<script>
import Header from './components/Header.vue'

export default {
  name: 'App',
  data() {
    return {
      title: '事前学習 - Vue応用',
      subtitle: 'Lesson12',
    }
  },
  components: {
    Header,
  },
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
img {
  width: 60%;
}
</style>
