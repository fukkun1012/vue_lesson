<template>
    <section v-if='Object.keys(userDetail).length !== 0'>
        <h3>ユーザ詳細</h3>
        <table>
            <tr>
                <th>ID</th>
                <td>{{ userDetail.id }}</td>
            </tr>
            <tr>
                <th>氏名</th>
                <td>{{ userDetail.name }}</td>
            </tr>
            <tr>
                <th>性別</th>
                <td>{{ userDetail.gender }}</td>
            </tr>
            <tr>
                <th>年齢</th>
                <td>{{ userDetail.age }}</td>
            </tr>
        </table>
    </section>
</template>

<script>
import { mapGetters } from 'vuex';
export default {
    computed: {
        ...mapGetters(['userDetail']),
    },
}
</script>

<style scoped>
table {
    margin: auto;
}
</style>