<template>
    <section>
        <h3>ユーザ一覧</h3>
        <table>
            <tr>
                <th>ID</th>
                <th>氏名</th>
                <th>-</th>
            </tr>
            <tr v-for='(user, index) in users' :key='user.id'>
                <td>{{ user.id }}</td>
                <td>{{ user.name }}</td>
                <td><button @click='toUserDetail(index)'>詳細</button></td>
            </tr>
        </table>
        <router-view></router-view>
    </section>
</template>

<script>
export default {
    data() {
        return {
            users: [
                {
                    id: 1,
                    name: '山田 太郎',
                    gender: '男',
                    age: 27,
                },
                {
                    id: 2,
                    name: '鈴木 花子',
                    gender: '女',
                    age: 25,
                },
                {
                    id: 3,
                    name: '田中 一朗',
                    gender: '男',
                    age: 31,
                }
            ]
        }
    },
    methods: {
        toUserDetail(index) {
            this.$store.dispatch('toUserDetail',this.users[index]);
            // Vue Routerは同じルーティングに２回アクセスするとエラーとなるため
            // 第２引数のコールバック処理で対応する
            this.$router.push('/users/detail/'+this.users[index].id, () => {});
        }
    }
}
</script>

<style scoped>
table {
    margin: auto;
    border-collapse: collapse;
    border: 1px solid #aaa;
}
th,td {
    border: 1px solid #aaa;
    padding: 5px
}
</style>