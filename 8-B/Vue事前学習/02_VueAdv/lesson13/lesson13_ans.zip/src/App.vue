<template>
  <div id="app">
    <Header>
      <template #title>
        <h1>{{ title }} <img alt="Vue logo" src="./assets/logo.png"></h1>
      </template>
      <template #subtitle>
        <h2>{{ subtitle }}</h2>
      </template>
      <hr/>
    </Header> 
    <ul>
      <li><button @click='style.outline = !style.outline'>外枠</button></li>
      <li><button @click='style.round = !style.round'>角丸</button></li>
      <li><button @click='style.shadow = !style.shadow'>影</button></li>
    </ul>
    <img 
      v-img-frame="{style}"
      alt='LiNew Office' 
      src='./assets/office.jpg'
    >
  </div>
</template>

<script>
import Header from './components/Header.vue'

export default {
  name: 'App',
  data() {
    return {
      title: '事前学習 - Vue応用',
      subtitle: 'Lesson13',
      style: {
        outline: false,
        round: false,
        shadow: false,
      }
    }
  },
  components: {
    Header,
  },
  directives: {
    imgFrame(el, binding) {
      let style = binding.value.style;
      // 枠線
      if(style.outline) {
        el.style.border = '1px solid darkgray';
        el.style.padding = '5px';
      } else {
        el.style.border = 0;
        el.style.padding = 0;
      }
      // 角丸
      if(style.round) {
        el.style.borderRadius = '10px';
      } else {
        el.style.borderRadius = 0;
      }
      // 影
      if(style.shadow) {
        el.style.boxShadow = '0 5px 10px rgba(0, 0, 0, 0.5)';
      } else {
        el.style.boxShadow = '0 0 0 transparent';
      }
    }
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
img {
  width: 60%;
}
ul {
  display: flex;
  justify-content: center;
  padding-inline-start: 0;
}
ul li {
  margin: 0 10px;
  list-style-type: none;
}
</style>
