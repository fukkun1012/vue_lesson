<template>
    <section v-if='Object.keys(userDetail).length !== 0'>
        <h3>ユーザ編集</h3>
        <transition name='fade' mode='out-in'>
            <p class='result' v-if="show">{{ message }}</p>
        </transition>
        <form id='user'>
        <table>
            <tr>
                <th>ID</th>
                <td>{{ userDetail.id }}
                    <input type='hidden' name='id' :value='userDetail.id'>
                </td>
            </tr>
            <tr>
                <th>氏名</th>
                <td><input type='text' name='name' :value='userDetail.name'></td>
            </tr>
            <tr>
                <th>メールアドレス</th>
                <td><input type='text' name='email' :value='userDetail.email'></td>
            </tr>
            <tr>
                <th>生年月日</th>
                <td><input type='date' name='birthday' :value='userDetail.birthday'></td>
            </tr>
            <tr>
                <th>性別</th>
                <td>
                    <input 
                        type='radio' 
                        name='gender' 
                        value='1' 
                        :checked='userDetail.gender === "1" ? "checked" : ""'>男
                    <input 
                        type='radio' 
                        name='gender' 
                        value='2' 
                        :checked='userDetail.gender === "2" ? "checked" : ""'>女                    
                </td>
            </tr>
        </table>
        </form>
        <button @click='updateUserData'>編 集</button>
    </section>
</template>

<script>
import { mapGetters } from 'vuex';
import axios from '@/axios-auth';
export default {
    data() {
        return {
            show: false,
            message: ''
        }
    },
    computed: {
        ...mapGetters(['userDetail']),
    },
    methods: {
        updateUserData() {
            let data = document.getElementById("user");
            const params = new FormData();
            params.append('id', data['id'].value);
            params.append('name', data['name'].value);
            params.append('email', data['email'].value);
            params.append('birthday', data['birthday'].value);
            params.append('gender', data['gender'].value);
            axios.post('/set.php', params)
            .then(response => {
                let user = {
                    id: data['id'].value,
                    name: data['name'].value,
                    email: data['email'].value,
                    birthday: data['birthday'].value,
                    gender: data['gender'].value,
                };
                // ストアの更新
                this.$store.dispatch('toUserDetail',user);
                
                // Usersコンポーネントのテーブル更新
                this.$emit('update-user');
                
                // エラーメッセージ表示
                this.show = true;
                if(response) {
                    this.message = 'ユーザ情報'+data['id'].value+'を更新しました';
                } else {
                    this.message = 'ユーザ情報の更新に失敗しました';
                }
                setTimeout(this.resultMessage, 1000);
            })
            .catch(error => {
                console.log(error);
                this.show = true;
                this.message = 'ユーザ情報の更新に失敗しました';
                setTimeout(this.resultMessage, 1000);
            });
        },
        resultMessage() {
            this.show = false;
        }
    },
}
</script>

<style scoped>
table {
    margin: auto;
    text-align: left;
}
th,td {
    padding: 3px;
}
th {
    background-color: #eee;
}
.result {
    color: red;
}
/* フェード */
.fade-enter-active {
  animation: fade-in 2s;
}
.fade-leave-active {
  animation: fade-in 2s reverse;
}
@keyframes fade-in {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  } 
}
</style>