<template>
    <section>
        <h3>このサイトについて</h3>
        <p>Lesson16の課題はルーティングについて学びます。<br>
        ルーティングは奥が深いのでしっかり理解して進めましょう。
        </p>
    </section>
</template>
