<template>
    <section>
        <h3>ユーザ一覧</h3>
        <template v-if='error'>
            <p>ユーザを取得できませんでした</p>
        </template>
        <template v-else>
            <table>
                <tr>
                    <th>ID</th>
                    <th>氏名</th>
                    <th>メールアドレス</th>
                    <th>生年月日</th>
                    <th>性別</th>
                    <th>-</th>
                </tr>
                <tr v-for='(user, index) in users' :key='user.id'>
                    <td>{{ user.id }}</td>
                    <td>{{ user.name }}</td>
                    <td>{{ user.email }}</td>
                    <td>{{ user.birthday }}</td>
                    <td>{{ user.gender === '1' ? '男' : '女' }}</td>
                    <td><button @click='toUserEdit(index)'>編集</button></td>
                </tr>
            </table>
            <router-view @update-user='updateUserData'></router-view>
        </template>
    </section>
</template>

<script>
import { mapGetters } from 'vuex';
import axios from '@/axios-auth';
export default {
    data() {
        return {
            users: {},
            error: false
        }
    },
    computed: {
        ...mapGetters(['userDetail']),
    },
    methods: {
        toUserEdit(index) {
            this.$store.dispatch('toUserDetail',this.users[index]);
            this.$router.push('/users/edit/'+this.users[index].id, () => {});
        },
        updateUserData() {
            let index = this.users.findIndex(e => e.id == this.userDetail.id);
            this.users.splice(index, 1, this.userDetail);
        }
    },
    created() {
        axios.get('/get.php')
        .then(response => {
            this.users = response.data;
        })
        .catch(error => {
            console.log(error);
            this.error = true;
        });
    },
}
</script>

<style scoped>
table {
    margin: auto;
    border-collapse: collapse;
    border: 1px solid #aaa;
}
th,td {
    border: 1px solid #aaa;
    padding: 5px
}
</style>