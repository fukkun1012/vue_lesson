<template>
    <section>
        <h3>ホーム</h3>
        <img alt='LiNew Office' src='@/assets/office.jpg'>
    </section>
</template>
