<template>
  <section>
    <img alt='LiNew Office' src='@/assets/office.jpg'>
  </section>
</template>


