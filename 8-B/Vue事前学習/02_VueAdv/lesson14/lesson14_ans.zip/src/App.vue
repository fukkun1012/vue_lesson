<template>
  <div id="app">
    <Header @page-link="pageLink($event)">
      <template #title>
        <h1>{{ title }} <img alt="Vue logo" src="./assets/logo.png"></h1>
      </template>
      <template #subtitle>
        <h2>{{ subtitle }}</h2>
      </template>
      <hr/>
    </Header>
    <!-- ここのコンポーネントを切り替え -->
    <keep-alive>
      <component 
        :is="currentComponent"
        :num='num' 
        @emit-num='count($event)'
      ></component>
    </keep-alive>
  </div>
</template>

<script>
import Header from './components/Header.vue'
import Home from './components/Home.vue'
import Form from './components/Form.vue'

export default {
  name: 'App',
  data() {
    return {
      // このデータを子に渡す
      title: '事前学習 - Vue応用',
      subtitle: 'ホームです',
      num: 0,
      currentComponent: 'Home',
    }
  },
  components: {
    Header,
    Home,
    Form,
  },
  methods: {
    pageLink(args) {
      this.currentComponent = args.page;
      this.subtitle = args.subtitle;
    },
    count(num) {
      this.num = num;
    }
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
img {
  width: 60%;
}
</style>
