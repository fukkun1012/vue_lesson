<template>
  <section>
      <label :for='value.label'>{{ value.label }} </label>
      <template v-for='(data, i) in select'>
        <input
          type="radio"
          :name="value.name"
          :key='data'
          :value="data"
          :checked="i == 0 ? 'checked' : ''"
          @input="$emit('input-data', $event.target.value)"
        >
        <label :for='value.label' :key='i'>{{ data }}</label>
      </template>
  </section>
</template>

<script>
export default {
  props: ['value','select']
}
</script>