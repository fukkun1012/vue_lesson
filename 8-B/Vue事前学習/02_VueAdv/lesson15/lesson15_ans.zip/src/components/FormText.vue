<template>
  <section>
      <label :for='value.label'>{{ value.label }} </label>
      <input
        type="text"
        :name="value.name"
        :id="value.label"
        :value="value.value"
        @input="$emit('input-data', $event.target.value)"
      >
  </section>
</template>

<script>
export default {
  props: ['value'],
}
</script>