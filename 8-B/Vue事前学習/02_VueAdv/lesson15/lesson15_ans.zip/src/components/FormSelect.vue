<template>
  <section>
      <label :for='value.label'>{{ value.label }} </label>
      <select :name='value.name' @input="$emit('input-data', $event.target.value)">
        <template v-for='(data, i) in select'>
          <option
            :key='data'
            :value="data"
            :checked="i == 0 ? 'checked' : ''"
          >
          {{ data }}
          </option>
        </template>
      </select>
  </section>
</template>

<script>
export default {
  props: ['value','select']
}
</script>