<template>
  <v-app>
    <v-app-bar
      app
      color="primary"
      dark
    >
      <div class="d-flex align-center">
        <v-img
          alt="Vuetify Logo"
          class="shrink mr-2"
          contain
          src="https://cdn.vuetifyjs.com/images/logos/vuetify-logo-dark.png"
          transition="scale-transition"
          width="40"
        />
        <h1 class='display-1' >Vue応用 - Lesson19</h1>
      </div>

      <v-spacer></v-spacer>

      <v-btn
        @click='logout'
        v-if="show"
        text
      >
        <span class="mr-2">ログアウト</span>
        <v-icon>logout</v-icon>
      </v-btn>
    </v-app-bar>

    <v-main>
      <router-view @login-out='isLogin'></router-view>
    </v-main>
  </v-app>
</template>

<script>
export default {
  name: 'App',
  data() {
    return {
      show: false
    }
  },
  methods: {
    logout() {
      this.$store.dispatch('logout');
      localStorage.clear();
      this.$router.push('/login', () => {});
      this.show = false;
    },
    isLogin() {
      let user = JSON.parse(localStorage.getItem('login'));
      this.show = user === null ? false : true;
    }
  },
};
</script>
