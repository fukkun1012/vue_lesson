const state = {
    user: {}
};

const mutations = {
    login(state, user) {
        state.user = user;
        localStorage.setItem('login',JSON.stringify(user));
    },
    logout(state) {
        state.user = {};
    }
};

const actions = {
    login(context, user) {
        context.commit('login', user);
    },
    logout(context) {
        context.commit('logout');
    }
};

const getters = {
    user: state => state.user,

};

export default {
    state,
    mutations,
    actions,
    getters,
}