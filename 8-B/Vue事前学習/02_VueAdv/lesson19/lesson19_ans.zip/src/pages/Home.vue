<template>
    <section>
        <h3 class='mt-16 text-center'>ホーム</h3>
        <v-img
            class='mx-auto'
            max-height="480"
            max-width="640"
            src="@/assets/office.jpg"
        ></v-img>
    </section>
</template>

<script>
export default {
    mounted() {
        let user = JSON.parse(localStorage.getItem('login'));
        if(user === null) {
            this.$router.push('/login', () => {});
        }
    }
}
</script>