<template>
    <section>
        <h1>404</h1>
        <h2>Page Not Found.</h2>
    </section>
</template>

<style scoped>
h1 {
    margin: 20px 0 0 0;
    font-size: 100px;
    font-weight: bold;
    color: gray
}
h2 {
    margin: 0;
    color: gray;
}
</style>
